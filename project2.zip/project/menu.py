whiletrue = True
import event_manager
import room_manager
import validators

userinput = validate_int(int(input("Please choose an option 1-5: ")))

while whiletrue:
    print("1. Manage Rooms")
    print("2. Manage Events")
    print("3. Check Room Availability")
    print("4. Reports")
    print("5. Exit")
    match userinput:
        case 1:
            manage_rooms()
        case 2:
            
        case 3:
            
            
        case 4:
            
        
        case 5:
            whiletrue = False
            
            
            
            