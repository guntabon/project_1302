from datetime import datetime
def get_valid_int(prompt):
    while True:
        user_input = input(prompt).upper().strip()
        if user_input == "Q":
            return
        try:
            return int(user_input)
        except ValueError:
            print("Invalid input. Please enter a valid number.")

def get_valid_float(prompt):
    while True:
        user_input = input(prompt).upper().strip()
        if user_input == "Q":
            return
        try:
            return float(user_input)
        except ValueError:
            print("Invalid input. Please enter a valid number.")

def get_valid_string(prompt):
    while True:
        user_input = input(prompt).upper().strip()
        if user_input == "Q":
            return
        if isinstance(user_input, str) and user_input.strip():
            return user_input
        print("Invalid input. Please enter a non-empty string.")
        
def get_valid_date(prompt):
    while True:
        user_input = input(prompt).upper().strip()
        if user_input == "Q":
            return
        try:
            datetime.strptime(user_input, "%Y-%m-%d")
            return user_input
        except ValueError:
            print("Invalid date format. Please enter a date in YYYY-MM-DD format.")
def get_valid_time(prompt):
    while True:
        user_input = input(prompt).upper().strip()
        if user_input == "Q":
            return
        try:
            # Expecting format HH:MM-HH:MM
            start_str, end_str = user_input.split("-")
            start = datetime.strptime(start_str.strip(), "%H:%M")
            end = datetime.strptime(end_str.strip(), "%H:%M")
            if end <= start:
                print("End time must be after start time.")
                continue
            return user_input
        except Exception:
            print("Invalid time range format. Please enter a range in HH:MM-HH:MM format.")