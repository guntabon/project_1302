
import event_manager
import room_manager
import validators

##Menu program
def Menu():
    ##While loop to control
    whiletrue = True
    while whiletrue:
        print("1. Manage Rooms")
        print("2. Manage Events")
        print("3. Check Room Availability")
        print("4. Reports")
        print("5. Exit")
        userinput = int(input("\nPlease choose an option 1-5: "))
        match userinput:
            ##We need to put cases 2-4 here, I just had this for testing purposes
            case 1:
                ## Referenced the room_manager.py using Manage_Rooms() method
                room_manager.Manage_Rooms()
                
            case 2:
            
            case 3:
            
            case 4:
      
            case 5:
                whiletrue = False
                
                
            
            