
import event_manager
import room_manager
import validators
import reports

##Menu program
def Menu():
    ##While loop to control
    whiletrue = True
    while whiletrue:
        print("1. Manage Rooms")
        print("2. Manage Events")
        print("3. Check Room Availability")
        print("4. Reports")
        print("5. Exit")
        userinput = int(input("\nPlease choose an option 1-5: "))
        match userinput:
            ##We need to put cases 2-4 here, I just had this for testing purposes
            case 1:
                ## Referenced the room_manager.py using Manage_Rooms() method
                room_manager.Manage_Rooms()
            case 2:
                ## Referenced the event_manager.py using Manage_Events() method
                event_manager.Manage_Events()

            case 4:
                reports.Report_manager()


            case 5:
                whiletrue = False
                
                
            
            