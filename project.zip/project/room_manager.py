##Imported room, validators and menu to reference between menus.
import room
import validators
import menu
import file_manager

##While loop control variable
whiletrue = True

##Defined addRoom, this asks for an input, gives it the chance to exit, then uppers/strips it and asks for the other variables if it isn't quit. 
# I also added a with/open file read and an if statement to check if the room number being entered already exists in the system. I'm treating it almost like a primary key check
def addRoom():
    roomNum = input("Please enter the room number or type Q to exit: ").strip().upper()
    if roomNum == "Q":
        return Manage_Rooms()
    file_manager.roomCheck(roomNum)
            
    roomCapacity = int(input("Enter the capacity of the room: "))
    roomType = input("Enter the type of room - Lab, Classroom, or Study Lounge: ").capitalize()
    ##Opens new data file, using the correct file pathing to the file folder. Opens it as infile to use later. 
    file_manager.addRooms(roomNum, roomCapacity, roomType)
    
    #Creates newRoom as a new object of the room class. room.Room is used here because it is referencing the room file and the Room class
    newRoom = room.Room(roomNum, roomCapacity, roomType)  
   
    ##Returns the value of newRoom.
    return newRoom

##Simple for statement. Displays all rooms currrently in the rooms.txt.
def listRooms():
    file_manager.listRooms()
 
 ## STILL NEEDS TO BE WRITTEN       
def cancelRoomTime():
    print("")

def Manage_Rooms():
    whileTrue = True
    while whileTrue:
        print("\n1. Add a Room")
        print("2. List all Rooms")
        print("4. Go back to main menu")
        userinput = int(input("Select an option 1-4: "))
        match userinput:
            case 1:
                addRoom()
            case 2:
                listRooms()
            case 4:
                menu.Menu()
            