##Imported room, validators and menu to reference between menus.
import room
import validators
import menu

##While loop control variable
whiletrue = True

##Defined addRoom, this asks for an input, gives it the chance to exit, then uppers/strips it and asks for the other variables if it isn't quit. 
# I also added a with/open file read and an if statement to check if the room number being entered already exists in the system. I'm treating it almost like a primary key check
def addRoom():
    roomNum = input("Please enter the room number or type Q to exit: ").strip().upper()
    if roomNum == "Q":
        return Manage_Rooms()
    with open("data/rooms/rooms.txt", "r") as infile:
        roomCheck = infile.readlines()
        if any(roomNum in line for line in roomCheck):
            print("Room already exists")
            return Manage_Rooms()
            
    roomCapacity = int(input("Enter the capacity of the room: "))
    roomType = input("Enter the type of room - Lab, Classroom, or Study Lounge: ").capitalize()
    userBooked = input("Is the room booked: Yes or No: ").strip().upper()
    
    ##If statement to check whether the room is booked or not. If the user inputs anything other than yes or no, it asks them to retry.
    if userBooked == "NO":
        isBooked = "No"
    elif userBooked == "YES":
        isBooked = "Yes"
    else:
        print("Please enter Yes or No: ")
        return Manage_Rooms()

    ##Assigns roomTimes to a int input variable
    roomTimes = int(input("Please enter the time slots available for the room (1, 2 or 3): "))
    
    ##Opens new data file, using the correct file pathing to the file folder. Opens it as infile to use later. 
    with open("data/rooms/rooms.txt", "a") as infile:
        ##Writes all the attributes to the room.txt. I added \n for line breaks to add readability.
        infile.write(f"Room Number: {roomNum}\n Room Capacity: {roomCapacity}\n Room type: {roomType}\n If booked: {isBooked}\n Room time slots: {roomTimes}\n")
    
    #Creates newRoom as a new object of the room class. room.Room is used here because it is referencing the room file and the Room class
    newRoom = room.Room(roomNum, roomCapacity, roomType, isBooked, roomTimes)  
   
    ##Returns the value of newRoom.
    return newRoom

##Simple for statement. Displays all rooms currrently in the rooms.txt.
def listRooms():
    with open("data/rooms/rooms.txt", "r") as infile:
        for lines in infile:
            print(lines.strip())
 
 ## STILL NEEDS TO BE WRITTEN       
def cancelRoomTime():
    print("")

def Manage_Rooms():
    whileTrue = True
    while whileTrue:
        print("\n1. Add a Room")
        print("2. List all Rooms")
        print("3. Cancel Room Time slot")
        print("4. Go back to main menu")
        userinput = int(input("Select an option 1-4: "))
        match userinput:
            case 1:
                addRoom()
            case 2:
                listRooms()
            case 3:
                cancelRoomTime()
            case 4:
                menu.Menu()
            