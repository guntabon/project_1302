import event
import menu
import file_manager
from datetime import datetime

def parse_time_range(time_range):
    start_str, end_str = time_range.split('-')
    start = datetime.strptime(start_str.strip(), "%H:%M")
    end = datetime.strptime(end_str.strip(), "%H:%M")
    return start, end

def checkTime(new_room, new_date, new_time, existing_events):
    """Return True if new_time on new_date in new_room overlaps any existing event.

    Returns:
      - "invalid" if new_time can't be parsed
      - True if overlap found
      - False if no overlap
    """
    # validate new_time first
    try:
        new_start, new_end = parse_time_range(new_time)
    except Exception:
        # invalid format for the new event time
        return "invalid"

    for evt in existing_events:
        try:
            evt_room = evt.get("room")
            evt_date = evt.get("date")
            if evt_room != new_room or evt_date != new_date:
                continue  # Skip events in other rooms or different dates

            existing_time = evt.get("time", "")
            existing_start, existing_end = parse_time_range(existing_time)

            # Check if time ranges overlap (start < other_end and end > other_start)
            if new_start < existing_end and new_end > existing_start:
                return True  # Overlap found
        except Exception:
            # Skip malformed stored event times
            continue

    return False  # No overlaps


def addEvent(room, date, time, attendance, event_type, club, contact):
    """Add an event after validating date/time format and checking overlaps.

    Prints a clear message when the room is booked or when the time/date format is invalid.
    """
    # validate date format
    try:
        datetime.strptime(date, "%Y-%m-%d")
    except Exception:
        print("Invalid date format. Expected YYYY-MM-DD. Event not added.")
        return

    existing_events = file_manager.getEvents()
    result = checkTime(room, date, time, existing_events)
    if result == "invalid":
        print("Invalid time format. Expected HH:MM-HH:MM. Event not added.")
        return
    if result is True:
        print("Cannot add event — room is booked at that date/time. Event not added.")
        return

    # All good: persist the event
    file_manager.addEvents(room, date, time, attendance, event_type, club, contact)
    print("Event added successfully.")

def Manage_Events():
    whileTrue = True
    while whileTrue:
        print("\n1. Add an Event")
        print("2. List all Events")
        print("3. Delete an Event")
        print("4. Go back to main menu")
        userinput = int(input("Select an option 1-4: "))


        match userinput:
            case 1:
                room = input("Enter room: ").strip().upper()
                date = input("Enter date (YYYY-MM-DD): ").strip()
                time = input("Enter time (HH:MM-HH:MM): ").strip()
                attendance = input("Enter expected attendance: ").strip()
                event_type = input("Enter event type: ").strip()
                club = input("Enter club name: ").strip()
                contact = input("Enter contact info: ").strip()
                addEvent(room, date, time, attendance, event_type, club, contact)
            case 2:
                events = file_manager.getEvents()
                if events:
                    for evt in events:
                        print(f"Room: {evt['room']}, Date: {evt.get('date','')}, Time: {evt['time']}, Attendance: {evt['attendance']}, Type: {evt['event_type']}, Club: {evt['club']}, Contact: {evt['contact']}")
                else:
                    print("No events scheduled.")
            
            case 3:
                file_manager.deleteEvents()
            case 4:
                menu.Menu()
  
    #    if __name__ == "__main__":
    #events = [
    #    {"room": "A", "time": "10:00-12:00"},
    #    {"room": "A", "time": "13:00-14:00"}, ]
    

    #new_event = ("A", "11:30-12:30")
   #overlap = checkTime(new_event[0], new_event[1], events)

    #if overlap:
    #    print("Times overlap!")
    #else:
    #    print("No overlap!")