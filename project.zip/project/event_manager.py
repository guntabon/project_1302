import event
import file_manager

def addEvent(room, time, attendance, event_type, club, contact):
    file_manager.addEvents(room, time, attendance, event_type, club, contact)


def checkTime():
    