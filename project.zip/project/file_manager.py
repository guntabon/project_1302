import os
import room
import room_manager
import event_manager
import validators

rooms = "data/rooms/rooms.txt"

##Defined addRoom, this asks for an input, gives it the chance to exit, then uppers/strips it and asks for the other variables if it isn't quit. 
# I also added a with/open file read and an if statement to check if the room number being entered already exists in the system. I'm treating it almost like a primary key check
def addRoom():
    roomNum = validators.get_valid_string("Enter the room number to add or type Q to exit: ").strip().upper()
    if roomNum == "Q":
        return room_manager.Manage_Rooms()
    if not roomCheck(roomNum):
        return room_manager.Manage_Rooms()
    # validate capacity input
    while True:
        try:
            roomCapacity = validators.get_valid_int("Enter the room capacity: ")
            break
        except ValueError:
            print("Please enter a valid whole number for capacity.")
    roomType = validators.get_valid_string("Enter the room type (e.g., Lecture Hall, Lab, Meeting Room): ").strip()
    ##Opens new data file, using the correct file pathing to the file folder. Opens it as infile to use later. 
    # ensure the rooms directory exists so open(..., 'a') won't fail
    rooms_dir = os.path.dirname(rooms)
    if rooms_dir:
        os.makedirs(rooms_dir, exist_ok=True)
    with open(rooms, "a") as outfile:
        outfile.write(f"Room Number: {roomNum}, Room Capacity: {roomCapacity}, Room Type: {roomType}\n")

def deleteRooms():
    """Delete a room if it has no scheduled events.
    
    Prompts user for room number, checks for conflicts, then removes from file.
    """

    listRooms()
    roomNum = validators.get_valid_int("Enter the room number to delete (or Q to exit): ")
    if roomNum == "Q":
        return room_manager.Manage_Rooms()
    
    # Check if room exists
    try:
        with open(rooms, "r") as infile:
            room_lines = infile.readlines()
    except FileNotFoundError:
        print("Room file not found.")
        return
    
    room_found = False
    for line in room_lines:
        if roomNum in line:
            room_found = True
            break
    
    if not room_found:
        print(f"Room {roomNum} not found.")
        return
    
    # Check if room has any scheduled events
    events = getEvents()
    room_has_events = any(event["room"].strip() == roomNum for event in events)
    
    if room_has_events:
        print(f"Cannot delete room {roomNum} — it has scheduled events.")
        return
    
    # Delete the room
    updated_lines = [line for line in room_lines if roomNum not in line]
    try:
        rooms_dir = os.path.dirname(rooms)
        if rooms_dir:
            os.makedirs(rooms_dir, exist_ok=True)
        with open(rooms, "w") as outfile:
            outfile.writelines(updated_lines)
        print(f"Room {roomNum} deleted successfully.")
    except FileNotFoundError:
        print("File not found.")

def roomCheck(myRoom):
    try:
        with open(rooms, "r") as infile:
            checkRoom = infile.readlines()
            if any(myRoom in line for line in checkRoom):
                print(f"Room {myRoom} already exists.")
                return False
            return True
    except FileNotFoundError:
        print("File not found.")
        return True
    
def eventCheck(myEvent):
    events_file = "data/events/events.txt"
    try:
        with open(events_file, "r") as infile:
            checkEvent = infile.readlines()
            if any(myEvent in line for line in checkEvent):
                print(f"Event {myEvent} already exists.")
                return False
            return True
    except FileNotFoundError:
        print("File not found.")
        return True

def addRooms(roomNum, roomCapacity, roomType):
    try:
        rooms_dir = os.path.dirname(rooms)
        if rooms_dir:
            os.makedirs(rooms_dir, exist_ok=True)
        with open(rooms, "a") as outfile:
            outfile.write(f"{roomNum},{roomCapacity},{roomType}\n")
    except FileNotFoundError:
        print("File not found. Creating new file.")    
        
def addEvents(room, date, time, attendance, event_type, club, contact):
    """Append an event record including date to the events file.

    Expected date format: YYYY-MM-DD. Caller should validate date/time formats.
    """
    events_file = "data/events/events.txt"
    try:
        events_dir = os.path.dirname(events_file)
        if events_dir:
            os.makedirs(events_dir, exist_ok=True)
        with open(events_file, "a") as outfile:
            outfile.write(f"{room},{date},{time},{attendance},{event_type},{club},{contact}\n")
    except FileNotFoundError:
        print("File not found. Creating new file.")
        
def listRooms():
    try:
        with open(rooms, "r") as infile:
            for lines in infile:
                print(lines.strip())
    except FileNotFoundError:
        print("File not found.")


def getEvents():
    """Read events from the events file and return a list of dicts.

    Each dict contains keys: room, date, time, attendance, event_type, club, contact.
    Returns an empty list if the file or directory does not exist or is empty.
    """
    events = []
    events_file = "data/events/events.txt"
    try:
        with open(events_file, "r") as infile:
            for line in infile:
                line = line.strip()
                if not line:
                    continue
                parts = line.split(",")
                # expect exactly 7 parts (room,date,time,attendance,event_type,club,contact)
                if len(parts) != 7:
                    continue
                evt = {
                    "room": parts[0].strip(),
                    "date": parts[1].strip(),
                    "time": parts[2].strip(),
                    "attendance": parts[3].strip(),
                    "event_type": parts[4].strip(),
                    "club": parts[5].strip(),
                    "contact": parts[6].strip(),
                }
                events.append(evt)
    except FileNotFoundError:
        # No events yet — return empty list rather than crashing
        return []
    return events


def deleteEvents():
    """Delete an event by room, date and time.
    
    Prompts user for room/date/time, then removes the matching event from file.
    """
    events = getEvents()
    if not events:
        print("No events to delete.")
        return

    # Display current events
    print("\nCurrent Events:")
    for i, evt in enumerate(events):
        print(f"{i+1}. Room: {evt['room']}, Date: {evt['date']}, Time: {evt['time']}, Club: {evt['club']}")
    
    with open(rooms, "r") as infile:
            for lines in infile:
                print(lines.strip())

    room = validators.get_valid_string("Enter room of event to delete (or Q to exit): ").strip().upper()


    date = validators.get_valid_date("Enter date of event to delete (YYYY-MM-DD) or Q to exit: ").strip()


    time = validators.get_valid_string("Enter time of event to delete (HH:MM-HH:MM) or Q to exit: ").strip()
    

    # Filter out the matching event
    updated_events = [evt for evt in events if not (evt["room"] == room and evt["date"] == date and evt["time"] == time)]

    if len(updated_events) == len(events):
        print(f"No event found for room {room} on {date} at time {time}.")
        return

    # Write updated events back to file (with date)
    events_file = "data/events/events.txt"
    try:
        events_dir = os.path.dirname(events_file)
        if events_dir:
            os.makedirs(events_dir, exist_ok=True)
        with open(events_file, "w") as outfile:
            for evt in updated_events:
                outfile.write(f"{evt['room']},{evt['date']},{evt['time']},{evt['attendance']},{evt['event_type']},{evt['club']},{evt['contact']}\n")
        print(f"Event deleted successfully.")
    except FileNotFoundError:
        print("File not found.")


def save_events_report(date_str, events_list, folder="reports/eventsfordate"):
    """Save a list of event dicts to a dated report file inside `folder`.

    Returns the path on success or raises an exception on failure.
    """
    reports_dir = os.path.normpath(folder)
    os.makedirs(reports_dir, exist_ok=True)
    report_path = os.path.join(reports_dir, f"{date_str}.txt")
    with open(report_path, "w", encoding="utf-8") as rf:
        rf.write(f"Events for {date_str} (sorted by room):\n")
        for evt in events_list:
            rf.write(f"Room: {evt['room']}, Time: {evt['time']}, Attendance: {evt['attendance']}, Type: {evt['event_type']}, Club: {evt['club']}, Contact: {evt['contact']}\n")
    return report_path