import room
import menu
import room_manager

rooms = "data/rooms/rooms.txt"

def roomCheck(myRoom):
    try:
        with open(rooms, "r") as infile:
            checkRoom = infile.readlines()
            if any(myRoom in line for line in checkRoom):
                return room_manager.Manage_Rooms()
            
    except FileNotFoundError:
        print("File not found.")
        return room_manager.Manage_Rooms()
    

def addRooms(roomNum, roomCapacity, roomType):
    try:
        with open(rooms, "a") as outfile:
            outfile.write(f"{roomNum},{roomCapacity},{roomType}\n")
    except FileNotFoundError:
        print("File not found. Creating new file.")
        

def addEvents(room, time, attendance, event_type, club, contact):
    events_file = "data/events/events.txt"
    try:
        with open(events_file, "a") as outfile:
            outfile.write(f"{room},{time},{attendance},{event_type},{club},{contact}\n")
    except FileNotFoundError:
        print("File not found.")
        
        
def listRooms():
    try:
        with open(rooms, "r") as infile:
            for lines in infile:
                print(lines.strip())
    except FileNotFoundError:
        print("File not found.")