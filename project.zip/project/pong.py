"""
Simple Pong game using pygame
Controls:
 - Left paddle: W (up), S (down)
 - Right paddle: Up Arrow, Down Arrow
 - R to restart after someone wins
 - ESC or close window to quit

Requires: pygame
Run with Python 3 (install pygame: pip install pygame)
"""

import pygame
import sys
import random

# --- Configuration ---
WIDTH, HEIGHT = 800, 600
FPS = 60
PADDLE_WIDTH, PADDLE_HEIGHT = 10, 100
BALL_SIZE = 16
PADDLE_SPEED = 6
BALL_SPEED = 5
WINNING_SCORE = 10

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)


class Paddle:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, PADDLE_WIDTH, PADDLE_HEIGHT)
        self.speed = PADDLE_SPEED

    def move(self, dy):
        self.rect.y += dy
        # keep in screen
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > HEIGHT:
            self.rect.bottom = HEIGHT

    def draw(self, surf):
        pygame.draw.rect(surf, WHITE, self.rect)


class Ball:
    def __init__(self):
        self.rect = pygame.Rect(WIDTH // 2 - BALL_SIZE // 2, HEIGHT // 2 - BALL_SIZE // 2, BALL_SIZE, BALL_SIZE)
        self.reset()

    def reset(self, direction=None):
        self.rect.center = (WIDTH // 2, HEIGHT // 2)
        angle = random.uniform(-0.5, 0.5)  # slight vertical angle
        dir_x = direction if direction is not None else random.choice([-1, 1])
        self.vel = [BALL_SPEED * dir_x, BALL_SPEED * angle]

    def update(self, left_paddle, right_paddle):
        self.rect.x += self.vel[0]
        self.rect.y += self.vel[1]

        # bounce top/bottom
        if self.rect.top <= 0:
            self.rect.top = 0
            self.vel[1] *= -1
        if self.rect.bottom >= HEIGHT:
            self.rect.bottom = HEIGHT
            self.vel[1] *= -1

        # paddle collisions
        if self.rect.colliderect(left_paddle.rect) and self.vel[0] < 0:
            self.rect.left = left_paddle.rect.right
            self.vel[0] *= -1.05  # increase speed slightly
            # change angle based on where it hit the paddle
            offset = (self.rect.centery - left_paddle.rect.centery) / (left_paddle.rect.height / 2)
            self.vel[1] = BALL_SPEED * offset

        if self.rect.colliderect(right_paddle.rect) and self.vel[0] > 0:
            self.rect.right = right_paddle.rect.left
            self.vel[0] *= -1.05
            offset = (self.rect.centery - right_paddle.rect.centery) / (right_paddle.rect.height / 2)
            self.vel[1] = BALL_SPEED * offset

    def draw(self, surf):
        pygame.draw.ellipse(surf, WHITE, self.rect)


def draw_centered_text(surf, text, size, y):
    font = pygame.font.Font(None, size)
    r = font.render(text, True, WHITE)
    rect = r.get_rect(center=(WIDTH // 2, y))
    surf.blit(r, rect)


def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption('Pong')
    clock = pygame.time.Clock()

    # Create objects
    left = Paddle(20, HEIGHT // 2 - PADDLE_HEIGHT // 2)
    right = Paddle(WIDTH - 20 - PADDLE_WIDTH, HEIGHT // 2 - PADDLE_HEIGHT // 2)
    ball = Ball()

    score_left = 0
    score_right = 0
    running = True
    paused = False
    winner = None

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                if event.key == pygame.K_r and winner is not None:
                    # restart match
                    score_left = 0
                    score_right = 0
                    ball.reset()
                    winner = None

        keys = pygame.key.get_pressed()
        # Left paddle (W/S)
        if keys[pygame.K_w]:
            left.move(-left.speed)
        if keys[pygame.K_s]:
            left.move(left.speed)
        # Right paddle (Up/Down)
        if keys[pygame.K_UP]:
            right.move(-right.speed)
        if keys[pygame.K_DOWN]:
            right.move(right.speed)

        if winner is None:
            ball.update(left, right)

            # Check scoring
            if ball.rect.left <= 0:
                score_right += 1
                if score_right >= WINNING_SCORE:
                    winner = 'Right Player'
                ball.reset(direction=1)

            if ball.rect.right >= WIDTH:
                score_left += 1
                if score_left >= WINNING_SCORE:
                    winner = 'Left Player'
                ball.reset(direction=-1)

        # Draw
        screen.fill(BLACK)
        # middle line
        for i in range(10, HEIGHT, 40):
            pygame.draw.rect(screen, WHITE, (WIDTH // 2 - 1, i, 2, 20))

        left.draw(screen)
        right.draw(screen)
        ball.draw(screen)

        # Scores
        font = pygame.font.Font(None, 64)
        left_surf = font.render(str(score_left), True, WHITE)
        right_surf = font.render(str(score_right), True, WHITE)
        screen.blit(left_surf, (WIDTH // 4 - left_surf.get_width() // 2, 20))
        screen.blit(right_surf, (3 * WIDTH // 4 - right_surf.get_width() // 2, 20))

        if winner:
            draw_centered_text(screen, f"{winner} wins! Press R to restart", 42, HEIGHT // 2)

        pygame.display.flip()
        clock.tick(FPS)

    pygame.quit()
    sys.exit()


if __name__ == '__main__':
    main()
